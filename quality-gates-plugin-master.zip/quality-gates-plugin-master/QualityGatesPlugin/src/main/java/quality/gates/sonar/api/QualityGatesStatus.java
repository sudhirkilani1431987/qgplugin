package quality.gates.sonar.api;


public enum QualityGatesStatus {
	GREEN,
	ORANGE,
	RED;
}
