# quality-gates-plugin
Jenkins plugin that fails the build if SonarQube quality gates are not green.
It is also possible to allow builds to be marked unstable for projects where the 
quality gate returned by a Sonar server is orange.

You can find the documentation on the next link:
https://wiki.jenkins-ci.org/display/JENKINS/Quality+Gates+Plugin
